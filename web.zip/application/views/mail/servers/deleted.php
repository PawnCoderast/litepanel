
Здравствуйте, <?php echo $lastname ?> <?php echo $firstname ?>!

Уведомляем Вас об удалении сервера #<?php echo $serverid ?>.

С уважением,
Администрация CompanyName!
