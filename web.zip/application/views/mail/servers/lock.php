
Здравствуйте, <?php echo $lastname ?> <?php echo $firstname ?>!

Уведомляем Вас о блокировке сервера #<?php echo $serverid ?>.
Сервер будет удален через 3 дня после блокировки.

С уважением,
Администрация CompanyName!
