
Здравствуйте, <?php echo $lastname ?> <?php echo $firstname ?>!

Уведомляем Вас о необходимости оплаты сервера #<?php echo $serverid ?>.
До окончания оплаченного периода осталось <?php echo $days ?> дня.

С уважением,
Администрация CompanyName!
