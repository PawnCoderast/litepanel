
Здравствуйте, <?php echo $lastname ?> <?php echo $firstname ?>!

Вы сделали запрос на восстановления доступа!

Для восстановления пароля перейдите по ссылке:
<?php echo $restorelink ?>


С уважением,
Администрация CompanyName!
