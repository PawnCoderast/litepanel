<?php echo $loginheader ?>
		<div class="form-signin">
			<h2 class="form-signin-heading">Восстановление</h2>
			<p class="lead">Новый пароль: <strong><?php echo $password ?></strong></p>
			<p class="text-center text-muted">Уважаемый клиент, мы не рекомендуем использовать данный пароль для постоянного использования.</p>
			<div class="other-link"><a href="/account/edit#new-password">Изменить пароль</a></div>
		</form>
<?php echo $loginfooter ?>
