<?php
$config = array(
	'title'			=>		'Arbite-Host',
	'description'	=>		'Sanya Games',
	'keywords'		=>		'Sanya Games',
	'url'			=>		'http://arbite-host.tk/',
	'token'			=>		'MYTOKEN',
	'db_type'		=>		'mysql',
	'db_hostname'	=>		'localhost',
	'db_username'	=>		'admin',
	'db_password'	=>		'JUpTJSdNlb2K',
	'db_database'	=>		'panel',
	'mail_from'		=>		'Arbite-Host@gmail.com',
	'mail_sender'	=>		'Arbite-Host Support',
	'rk_server'		=>		'https://merchant.roboxchange.com',
	'rk_login'		=>		'login',
	'rk_password1'	=>		'pass1',
	'rk_password2'	=>		'pass2',
	'unitpay_url'	=>		'unitppayurl',
	'unitpay_secret'=>		'unitpaysecret'
);
?>